module SerialsHelper
end
