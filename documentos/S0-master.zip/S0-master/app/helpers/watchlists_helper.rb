module WatchlistsHelper
end
