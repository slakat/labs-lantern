Links de heroku

users
http://showganizer-www.herokuapp.com/users

tv series
http://showganizer-www.herokuapp.com/serials

movies
http://showganizer-www.herokuapp.com/movies


*Usamos serials, ya que series para rails es plural y singular.