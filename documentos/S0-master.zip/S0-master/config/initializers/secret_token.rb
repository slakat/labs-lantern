# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
S0::Application.config.secret_key_base = '58d16d67e337587d63b33e70a103492d4126cc5fd9a43da6fc28dc2baac0bc2f14d4725da1ca47364477f7425285979eb841d7e4007921ae5173fdccbca9579e'
