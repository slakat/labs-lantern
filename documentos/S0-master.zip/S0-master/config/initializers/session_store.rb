# Be sure to restart your server when you modify this file.

S0::Application.config.session_store :cookie_store, key: '_S0_session'
