require 'test_helper'

class MoviesHelperTest < ActionView::TestCase
end
