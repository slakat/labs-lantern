require 'test_helper'

class WatchedHelperTest < ActionView::TestCase
end
