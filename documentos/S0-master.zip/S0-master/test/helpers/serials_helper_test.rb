require 'test_helper'

class SerialsHelperTest < ActionView::TestCase
end
