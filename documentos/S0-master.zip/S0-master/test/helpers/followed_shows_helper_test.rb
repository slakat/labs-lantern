require 'test_helper'

class FollowedShowsHelperTest < ActionView::TestCase
end
