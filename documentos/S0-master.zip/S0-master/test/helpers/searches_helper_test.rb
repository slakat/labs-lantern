require 'test_helper'

class SearchesHelperTest < ActionView::TestCase
end
