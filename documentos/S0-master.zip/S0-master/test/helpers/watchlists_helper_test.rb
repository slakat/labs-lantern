require 'test_helper'

class WatchlistsHelperTest < ActionView::TestCase
end
