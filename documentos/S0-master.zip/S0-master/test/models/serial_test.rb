require 'test_helper'

class SerialTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
