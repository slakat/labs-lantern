require 'test_helper'

class SerialsUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
