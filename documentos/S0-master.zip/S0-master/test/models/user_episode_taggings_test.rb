require 'test_helper'

class UserEpisodeTaggingsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
