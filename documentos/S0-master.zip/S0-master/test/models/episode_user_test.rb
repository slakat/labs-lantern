require 'test_helper'

class EpisodeUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
