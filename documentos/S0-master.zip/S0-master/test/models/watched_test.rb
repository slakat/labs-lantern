require 'test_helper'

class WatchedTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
