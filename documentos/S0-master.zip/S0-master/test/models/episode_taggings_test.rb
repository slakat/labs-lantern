require 'test_helper'

class EpisodeTaggingsTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
