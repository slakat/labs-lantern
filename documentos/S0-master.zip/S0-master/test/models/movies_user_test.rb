require 'test_helper'

class MoviesUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
