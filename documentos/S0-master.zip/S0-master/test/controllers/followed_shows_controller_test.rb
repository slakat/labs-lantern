require 'test_helper'

class FollowedShowsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
