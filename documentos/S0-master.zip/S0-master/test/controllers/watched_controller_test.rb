require 'test_helper'

class WatchedControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
